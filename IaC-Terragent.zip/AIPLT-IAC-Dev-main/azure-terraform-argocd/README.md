# Azure Terraform ArgoCD Project

This project demonstrates how to create an Azure resource group using Terraform and deploy it using ArgoCD on a local Kubernetes cluster created with Minikube.

## Project Structure

```
azure-terraform-argocd
├── terraform
│   ├── main.tf          # Main Terraform configuration
│   ├── variables.tf     # Input variables for Terraform
│   ├── outputs.tf       # Outputs from Terraform
│   └── provider.tf      # Azure provider configuration
├── argocd
│   ├── application.yaml  # ArgoCD application configuration
│   └── kustomization.yaml # Kustomization for ArgoCD
├── kubernetes
│   ├── deployment.yaml   # Kubernetes deployment configuration
│   ├── service.yaml      # Kubernetes service configuration
│   └── ingress.yaml      # Ingress configuration for the application
├── scripts
│   ├── setup-minikube.sh # Script to set up Minikube
│   ├── deploy-argocd.sh  # Script to deploy ArgoCD
│   └── apply-terraform.sh # Script to apply Terraform configuration
├── .gitignore            # Git ignore file
└── README.md             # Project documentation
```

## Prerequisites

- An Azure account
- Terraform installed
- Minikube installed
- kubectl installed
- ArgoCD installed

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone <repository-url>
   cd azure-terraform-argocd
   ```

2. **Set up Minikube:**
   Run the setup script to initialize Minikube:
   ```
   ./scripts/setup-minikube.sh
   ```

3. **Deploy ArgoCD:**
   Use the deploy script to install ArgoCD on your Minikube cluster:
   ```
   ./scripts/deploy-argocd.sh
   ```

4. **Configure Terraform:**
   Update the `variables.tf` file with your desired resource group name and location.

5. **Apply Terraform configuration:**
   Run the script to apply the Terraform configuration:
   ```
   ./scripts/apply-terraform.sh
   ```

6. **Access ArgoCD:**
   Follow the instructions in the ArgoCD documentation to access the ArgoCD UI and manage your applications.

## Usage

This project allows you to manage Azure resources using Terraform and deploy them using ArgoCD, providing a streamlined CI/CD process for infrastructure management.

## License

This project is licensed under the MIT License. See the LICENSE file for details.