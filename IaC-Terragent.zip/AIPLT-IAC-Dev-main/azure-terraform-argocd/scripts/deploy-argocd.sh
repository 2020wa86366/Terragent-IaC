#!/bin/bash

# filepath: /Users/fleminpaulson/Wipro-Emu/AIPLT-IAC-Dev/azure-terraform-argocd/scripts/deploy-argocd.sh

# Set variables
NAMESPACE=argocd

# Function to check if a namespace exists
function check_namespace_exists {
  if kubectl get namespace $NAMESPACE &> /dev/null; then
    echo "Namespace $NAMESPACE already exists."
    return 0
  else
    echo "Namespace $NAMESPACE does not exist."
    return 1
  fi
}

# Create namespace for ArgoCD if it does not exist
if ! check_namespace_exists; then
  echo "Creating namespace $NAMESPACE..."
  kubectl create namespace $NAMESPACE
else
  echo "Skipping namespace creation."
fi

# Install ArgoCD
kubectl apply -n $NAMESPACE -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for ArgoCD server to be ready
kubectl wait --for=condition=available --timeout=600s deployment/argocd-server -n $NAMESPACE

# Port forwarding for ArgoCD server
kubectl port-forward svc/argocd-server -n argocd 8080:443 &
echo "ArgoCD server is accessible at https://localhost:8080"

# Retrieve the initial admin password
ADMIN_PASSWORD=$(kubectl get secret argocd-initial-admin-secret -n argocd -o jsonpath="{.data.password}" | base64 --decode)
echo "ArgoCD admin password: $ADMIN_PASSWORD"

# Log in to ArgoCD using the CLI
argocd login localhost:8080 --username admin --password $ADMIN_PASSWORD --insecure

# Print ArgoCD server URL
echo "ArgoCD server is running. Access it at: https://localhost:8080"
echo "To access the UI, use the following command to port-forward:"
echo "kubectl port-forward svc/argocd-server -n $NAMESPACE 8080:443"