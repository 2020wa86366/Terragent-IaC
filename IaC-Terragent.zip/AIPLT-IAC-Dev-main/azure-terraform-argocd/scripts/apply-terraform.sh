#!/bin/bash

# Retrieve secrets from Kubernetes and export as environment variables
export ARM_CLIENT_ID=$(kubectl get secret azure-credentials -o jsonpath="{.data.client-id}" | base64 --decode)
export ARM_CLIENT_SECRET=$(kubectl get secret azure-credentials -o jsonpath="{.data.client-secret}" | base64 --decode)
export ARM_SUBSCRIPTION_ID=$(kubectl get secret azure-credentials -o jsonpath="{.data.subscription-id}" | base64 --decode)
export ARM_TENANT_ID=$(kubectl get secret azure-credentials -o jsonpath="{.data.tenant-id}" | base64 --decode)
export GITHUB_TOKEN=$(kubectl get secret github-pat -o jsonpath="{.data.pat-token}" | base64 --decode)

# Navigate to the Terraform directory
cd ../terraform

# Initialize Terraform
terraform init

# Apply the Terraform configuration with variables passed from environment variables
terraform apply -auto-approve \
  -var "subscription_id=$ARM_SUBSCRIPTION_ID" \
  -var "client_id=$ARM_CLIENT_ID" \
  -var "client_secret=$ARM_CLIENT_SECRET" \
  -var "tenant_id=$ARM_TENANT_ID"

# Navigate back to the scripts directory
cd ../scripts

# Optionally, you can add any additional commands or logging here
echo "Terraform apply completed."