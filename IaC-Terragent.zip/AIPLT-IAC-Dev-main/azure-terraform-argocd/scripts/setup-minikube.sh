#!/bin/bash

# filepath: /Users/fleminpaulson/Wipro-Emu/AIPLT-IAC-Dev/azure-terraform-argocd/scripts/setup-minikube.sh

# Function to check if Minikube is installed
function check_minikube_installed {
  if command -v minikube &> /dev/null; then
    echo "Minikube is already installed."
    return 0
  else
    echo "Minikube is not installed."
    return 1
  fi
}

# Install Minikube if not installed
if ! check_minikube_installed; then
  echo "Installing Minikube..."
  sudo apt-get update
  sudo apt-get install -y apt-transport-https ca-certificates curl
  curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
  sudo install minikube-linux-amd64 /usr/local/bin/minikube
  rm minikube-linux-amd64
else
  echo "Skipping Minikube installation."
fi

# Start Minikube
minikube start --driver=docker

# Enable Ingress addon
#minikube addons enable ingress

# Verify Minikube installation
minikube status

# Print Minikube IP
echo "Minikube IP: $(minikube ip)"